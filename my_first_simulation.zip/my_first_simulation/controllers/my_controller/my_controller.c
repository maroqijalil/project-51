#include <webots/motor.h>
#include <webots/robot.h>
#include <webots/camera.h>
#include <webots/distance_sensor.h>
#include <stdio.h>
#include <stdlib.h>
#include <webots/utils/system.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <webots/display.h>

#define TIME_STEP 64

unsigned char *hasil_img;

int main(int argc, char **argv) {
    wb_robot_init();
    int i, w, h;
    bool avoid_obstacle_counter = 0;
    WbDeviceTag ds[3];
    double p_a= 0.0;
    double p_b= 0.0;
    WbDeviceTag sodoker = wb_robot_get_device("sodok");
    WbDeviceTag capit_a = wb_robot_get_device("capit_a");
    WbDeviceTag capit_b = wb_robot_get_device("capit_b");
    WbDeviceTag camera = wb_robot_get_device("camera");
    char ds_names[3][10] = {"ds_left", "ds_right", "ds_top"};
    for (i = 0; i < 3; i++) {
        ds[i] = wb_robot_get_device(ds_names[i]);
        wb_distance_sensor_enable(ds[i], TIME_STEP);
     }
     
     wb_camera_enable(camera,TIME_STEP);
     w = wb_camera_get_width(camera);
     h = wb_camera_get_height(camera);
     int ukuran = 4*w*h*sizeof(unsigned char*);
     
     
     wb_motor_set_position(capit_a, p_a);
     WbDeviceTag wheels[4];
     char wheels_names[4][8] = {"wheel1", "wheel2", "wheel3", "wheel4"};
     for (i = 0; i < 4; i++) {
         wheels[i] = wb_robot_get_device(wheels_names[i]);
         wb_motor_set_position(wheels[i], INFINITY);
     }
     wb_motor_set_position(capit_a, p_a + 2);
     wb_motor_set_position(capit_b, p_a - 2);
     
     static unsigned char *image = wb_camera_get_image(camera);
     wb_display_image_new(camera, width, height, image, WB_IMAGE_BGRA);
     
     while (wb_robot_step(TIME_STEP) != -1) {
         wb_motor_set_position(sodoker, p_b);
         double left_speed = 1.0;
         double right_speed = 1.0;
         if (avoid_obstacle_counter > 0) {
             avoid_obstacle_counter--;
             left_speed = -1.0;
             right_speed = 1.0;
             wb_motor_set_position(sodoker, p_b + 0.02);
         }
         else { // read sensors
             double ds_values[3];
             for (i = 0; i < 3; i++)
             ds_values[i] = wb_distance_sensor_get_value(ds[i]);
             if (ds_values[0] < 950.0 || ds_values[1] < 950.0 || ds_values[2] < 950.0)
             avoid_obstacle_counter = 100;
             wb_motor_set_position(sodoker, p_b);
         }
         wb_motor_set_velocity(wheels[0], left_speed);
         wb_motor_set_velocity(wheels[1], right_speed);
         wb_motor_set_velocity(wheels[2], left_speed);
         wb_motor_set_velocity(wheels[3], right_speed);
     }
     wb_robot_cleanup();
     return 0;  // EXIT_SUCCESS
}
